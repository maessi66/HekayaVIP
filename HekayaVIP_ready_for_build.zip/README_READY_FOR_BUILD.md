HekayaVIP — Prepared for build

What I did:
- Updated buildozer.spec to a safe configuration and disabled git check (git = 0) for Pydroid environments.
- Added GitHub Actions workflow at .github/workflows/android.yml to build a debug APK and upload as artifact.
- Sanitized obvious plaintext secrets if present (email/password/api_key patterns).

Important:
- I cannot run Buildozer here to produce the APK. Use GitHub Actions (push this repo) or a Linux machine to run `buildozer android debug`.
- If you want a signed release APK I can prepare signing instructions and files but you'll need to supply keystore or create one locally.

To build on GitHub:
1. Create a repo on GitHub and upload the contents of this folder.
2. Go to Actions -> Build Android APK -> Run workflow.
3. After the run completes, download the artifact named 'apk'.

If you want me to further tweak package name, icon, or requirements, tell me and I'll update the project.
